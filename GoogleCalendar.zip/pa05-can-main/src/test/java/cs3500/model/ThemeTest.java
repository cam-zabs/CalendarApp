package cs3500.model;

import cs3500.pa05.model.entries.Theme;

/**
 * Represents a test for Themes
 */
class ThemeTest {
  Theme theme1 = Theme.LIGHT;
  Theme theme2 = Theme.DARK;
  Theme theme3 = Theme.HUSKY;
}