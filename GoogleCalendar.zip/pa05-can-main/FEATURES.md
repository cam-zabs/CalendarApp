## Section 1: Requirements
- Week View
- Event and Task Creation
- Commitment Warnings
- Persistence

## Section 2: Headlining Features
Themes
Task Que 

## Section 3: Power Ups
Progress Bar
Quotes and Notes
Weekly Overview

## Section 4: Quality of Life
URLs 
Custom Theme

## Section 5: Extra Credit
Visual Flourish
